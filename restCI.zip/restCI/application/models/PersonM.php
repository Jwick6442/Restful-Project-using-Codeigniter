<?php
// extends class Model
class PersonM extends CI_Model{
// response jika field ada yang kosong
  public function empty_response(){
    $response['status']=502;
    $response['error']=true;
    $response['message']='Please Fill This Field';
    return $response;
  }
// function untuk insert data ke tabel tb_cap
  public function add_person($brand,$colour,$price,$size){
if(empty($brand) || empty($colour) || empty($price) || empty($size)){
      return $this->empty_response();
    }else{
      $data = array(
        "brand"=>$brand,
        "colour"=>$colour,
        "price"=>$price,
        "size"=>$size,
      );
$insert = $this->db->insert("tb_cap", $data);
if($insert){
        $response['status']=200;
        $response['error']=false;
        $response['message']='Person Data Added.';
        return $response;
      }else{
        $response['status']=502;
        $response['error']=true;
        $response['message']='Person Data Failed to Added.';
        return $response;
      }
    }
}
// mengambil semua data person
  public function all_person(){
$all = $this->db->get("tb_cap")->result();
    $response['status']=200;
    $response['error']=false;
    $response['person']=$all;
    return $response;
}
// hapus data person
  public function delete_person($id){
if($id == ''){
      return $this->empty_response();
    }else{
      $where = array(
        "id"=>$id
      );
$this->db->where($where);
      $delete = $this->db->delete("tb_cap");
      if($delete){
        $response['status']=200;
        $response['error']=false;
        $response['message']='Person Data Deleted.';
        return $response;
      }else{
        $response['status']=502;
        $response['error']=true;
        $response['message']='Person Data Failed to Deleted.';
        return $response;
      }
    }
}
// update person
  public function update_person($id,$brand,$colour,$price,$size){
if($id == '' || empty($brand) || empty($colour) || empty($price)|| empty($size)){
      return $this->empty_response();
    }else{
      $where = array(
        "id"=>$id
      );
$set = array(
        "brand"=>$brand,
        "colour"=>$colour,
        "price"=>$price,
        "size"=>$size,
      );
$this->db->where($where);
      $update = $this->db->update("tb_cap",$set);
      if($update){
        $response['status']=200;
        $response['error']=false;
        $response['message']='Person Data Changed.';
        return $response;
      }else{
        $response['status']=502;
        $response['error']=true;
        $response['message']='Person Data Failed to Changed.';
        return $response;
      }
    }
}
}
?>